# Old examples

This folder contains examples from old versions of the library that have not 
been updated. Some of them might still work, others probably require minor 
tweaks to get them to compiler with the latest version of Control Surface. They
are preserved here for inspiration, but are not actively maintained.
