#pragma once

#include "../BLEAPI.hpp"

namespace cs::midi_ble_btstack {

void le_midi_setup_adv(const BLESettings &ble_settings);

} // namespace cs::midi_ble_btstack
