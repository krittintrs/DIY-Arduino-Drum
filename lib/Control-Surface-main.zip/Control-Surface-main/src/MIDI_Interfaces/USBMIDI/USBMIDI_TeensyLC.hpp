#include "USBMIDI_Teensy3.hpp"
BEGIN_CS_NAMESPACE
using TeensyLC_USBDeviceMIDIBackend = Teensy3_USBDeviceMIDIBackend;
END_CS_NAMESPACE
